package cidade;
import java.util.*;
import tads.Aresta;
import tads.ListaEncadeada;
import tads.No;
import tads.Vertice;

public abstract class Grafo {
    public ListaEncadeada<Vertice> vertices;
    public ListaEncadeada<Aresta> aresta;
    //GRAFO COM LISTA DINÂMICA
    //GRAFO COM LISTA ADJACÊNCIA
    //GRAFO VAI PRECISA DAS DUAS
    public abstract void adicionarAresta(Rua rua);
    public abstract void adicionarVertice(Intersecao intersecao);

    private Map<String, No> nos; // Armazena os nós
    private Map<String, List<Aresta>> adjacencia; // Lista de adjacência (nó -> lista de arestas)

    public Grafo() {
        nos = new HashMap<>();
        adjacencia = new HashMap<>();
    }

    // Método para adicionar um nó ao grafo
    public void adicionarNo(String id) {
        No no = new No(id);
        nos.put(id, no);
        adjacencia.put(id, new ArrayList<>()); // Inicializa a lista de adjacência do nó
    }

    // Método para adicionar uma aresta entre dois nós
    public void adicionarAresta(String idOrigem, String idDestino, double comprimento, double velocidadeMaxima, boolean sentidoUnico) {
        No origem = nos.get(idOrigem);
        No destino = nos.get(idDestino);

        if (origem != null && destino != null) {
            Aresta aresta = new Aresta(destino, comprimento, velocidadeMaxima, sentidoUnico);
            adjacencia.get(idOrigem).add(aresta);

            // Se a aresta não for de sentido único, adicionamos a aresta reversa também
            if (!sentidoUnico) {
                Aresta arestaReversa = new Aresta(origem, comprimento, velocidadeMaxima, sentidoUnico);
                adjacencia.get(idDestino).add(arestaReversa);
            }
        }
    }

    // Método para mostrar todos os nós do grafo
    public void mostrarNos() {
        for (No no : nos.values()) {
            System.out.println(no);
        }
    }

    // Método para mostrar todas as arestas de cada nó
    public void mostrarArestas() {
        for (Map.Entry<String, List<Aresta>> entry : adjacencia.entrySet()) {
            String origem = entry.getKey();
            List<Aresta> arestas = entry.getValue();
            for (Aresta aresta : arestas) {
                System.out.println("De " + origem + " para " + aresta.getDestino().getId() + ": " + aresta);
            }
        }
    }

    // Método para obter um nó específico
    public No getNo(String id) {
        return nos.get(id);
    }
}


package cidade;

public class Mapa {
    public void carregarMapa() {
        //Gerar um grafo com o mapa da cidade
    }
}
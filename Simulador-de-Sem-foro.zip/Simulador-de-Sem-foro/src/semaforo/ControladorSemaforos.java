package semaforo;

public class ControladorSemaforos {


    //Aqui a gente define as quais regras serão usadas
    public void aplicarControle() {

    }
}
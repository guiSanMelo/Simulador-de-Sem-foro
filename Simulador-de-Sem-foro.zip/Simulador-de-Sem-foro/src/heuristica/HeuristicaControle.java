package heuristica;

public class HeuristicaControle {
    public void aplicar1() { //Ciclo fixo

    }

    public void aplicar2(){//

    }

    public void aplicar3(){//o

    }
}
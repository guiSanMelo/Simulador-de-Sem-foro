package trafego;

public class GeradorVeiculos {
    public void gerar() {
        System.out.println("Veículos gerados aleatoriamente.");
    }
}
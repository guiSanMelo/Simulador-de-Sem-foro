package tads;

public class Vertice {
        String nome;
        // métodos como getNome(), equals(), hashCode()

}

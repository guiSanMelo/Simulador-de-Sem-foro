package tads;

public class Aresta {
    Vertice origem;
    Vertice destino;
    int custo;

    public Aresta(No destino, double comprimento, double velocidadeMaxima, boolean sentidoUnico) {
    }

    public Thread getDestino() {
        return null;
    }
}
